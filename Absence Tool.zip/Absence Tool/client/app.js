const SERVER = "http://localhost:3000";

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("loginForm").addEventListener("submit", login);
  document
    .getElementById("addAbsenceForm")
    .addEventListener("submit", addAbsence);
  // Other event listeners for the dynamic elements can be added after the table is populated
});

function getAbsences() {
  return fetch(SERVER + "/absences")
    .then((res) => res.json())
    .catch((err) => {
      console.error(`Error occurred: ${err}`);
    });
}

function login(event) {
  event.preventDefault();
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  var allowedUsername = "demirV";
  var allowedPassword = "Modul290*";

  if (username === allowedUsername && password === allowedPassword) {
    document.getElementById("login-form").style.display = "none";
    document.getElementById("absence-list").style.display = "block";
    populateTable();
  } else {
    alert("Invalid username or password");
  }
}

function populateTable() {
  getAbsences().then((data) => {
    if (data) {
      let tableBody = document.querySelector("#absence-list table tbody");
      tableBody.innerHTML = ""; // Clear the table body

      data.forEach((absence) => {
        let row = tableBody.insertRow();
        row.setAttribute("data-id", absence.ID); // Set data-id attribute
        row.innerHTML = `
                    <td>${absence.ID}</td>
                    <td>${absence.DATE}</td>
                    <td>${absence.SUBJECT}</td>
                    <td>${absence.TIMESLOT}</td>
                    <td>${absence.STATUS}</td>
                    <td>${absence.PERSON}</td>
                    <td>
                        <button onclick="editAbsence(this)">Edit</button>
                        <button onclick="deleteAbsence(${absence.ID})">Delete</button>
                    </td>
                `;
      });
    }
  });
}

function editAbsence(button) {
  let row = button.parentNode.parentNode;
  let cells = row.querySelectorAll("td:not(:last-child)"); // Exclude the last cell with buttons

  cells.forEach((cell, index) => {
    let input = document.createElement("input");
    input.type = "text";
    input.value = cell.innerText;
    cell.innerHTML = "";
    cell.appendChild(input);
  });

  button.textContent = "Save";
  button.setAttribute("onclick", `saveAbsence(${row.getAttribute("data-id")})`);
}

function saveAbsence(id) {
  let row = document.querySelector(`tr[data-id="${id}"]`);
  let inputs = row.querySelectorAll("input");
  let updatedData = {
    DATE: inputs[0].value,
    SUBJECT: inputs[1].value,
    TIMESLOT: inputs[2].value,
    STATUS: inputs[3].value,
    PERSON: inputs[4].value,
  };

  fetch(SERVER + "/absence/" + id, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updatedData),
  })
    .then((res) => res.json())
    .then(() => populateTable())
    .catch((err) => console.error(`Error occurred: ${err}`));
}

function saveAbsence(id) {
  let row = document.querySelector(`tr[data-id="${id}"]`);
  let inputs = row.querySelectorAll("input");
  let updatedData = {
    DATE: inputs[0].value,
    SUBJECT: inputs[1].value,
    TIMESLOT: inputs[2].value,
    STATUS: inputs[3].value,
    PERSON: inputs[4].value,
  };

  if (row.getAttribute("data-editing")) {
    row.removeAttribute("data-editing");
  }

  fetch(SERVER + "/absence/" + id, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updatedData),
  })
    .then((res) => res.json())
    .then(() => populateTable())
    .catch((err) => console.error(`Error occurred: ${err}`));
}

function deleteAbsence(id) {
  fetch(SERVER + "/absence/" + id, {
    method: "DELETE",
  })
    .then((res) => {
      if (!res.ok) {
        throw new Error(`Server responded with status ${res.status}`);
      }
      return res.json();
    })
    .then(() => {
      populateTable(); // Refresh table after deleting absence
    })
    .catch((err) => {
      console.error(`Error occurred: ${err}`);
    });
}

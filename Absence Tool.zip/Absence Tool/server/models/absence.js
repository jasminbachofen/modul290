const sql = require("../config/database.js");

class Absence {
  static async create(absence) {
    const [results] = await sql.query("INSERT INTO ABSENCE SET ?", absence);
    return { id: results.insertId, ...absence };
  }

  static async getById(id) {
    const [results] = await sql.query("SELECT * FROM ABSENCE WHERE ID = ?", [
      id,
    ]);
    return results[0] || null;
  }

  static async getAll() {
    const [results] = await sql.query("SELECT * FROM ABSENCE");
    return results;
  }

  static async updateById(id, absence) {
    const [results] = await sql.query("UPDATE ABSENCE SET ? WHERE ID = ?", [
      absence,
      id,
    ]);
    return results.affectedRows ? { id, ...absence } : null;
  }

  static async deleteById(id) {
    const [results] = await sql.query("DELETE FROM ABSENCE WHERE ID = ?", [id]);
    return results.affectedRows ? {} : null;
  }

  static async deleteAll() {
    const [results] = await sql.query("DELETE FROM ABSENCE");
    return results;
  }
}

module.exports = Absence;

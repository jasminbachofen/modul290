const controller = require("./controller.js");

module.exports = (app) => {
  app
    .route("/absences")
    .get(controller.findAll)
    .post(controller.create)
    .delete(controller.deleteAll);

  app
    .route("/absence/:id")
    .get(controller.findOne)
    .put(controller.update)
    .delete(controller.deleteOne);
};

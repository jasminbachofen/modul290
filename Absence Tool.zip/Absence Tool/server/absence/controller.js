const Absence = require("../models/absence.js");

const create = async (req, res) => {
  try {
    const result = await Absence.create(req.body);
    res.status(201).json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const findAll = async (req, res) => {
  try {
    const result = await Absence.getAll();
    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const findOne = async (req, res) => {
  try {
    const result = await Absence.getById(req.params.id);
    if (result) {
      res.json(result);
    } else {
      res
        .status(404)
        .json({ message: `Absence with id ${req.params.id} not found.` });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const update = async (req, res) => {
  try {
    const result = await Absence.updateById(req.params.id, req.body);
    if (result) {
      res.json(result);
    } else {
      res
        .status(404)
        .json({ message: `Absence with id ${req.params.id} not found.` });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const deleteOne = async (req, res) => {
  try {
    const result = await Absence.deleteById(req.params.id);
    if (result) {
      res.status(204).end();
    } else {
      res
        .status(404)
        .json({ message: `Absence with id ${req.params.id} not found.` });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const deleteAll = async (req, res) => {
  try {
    await Absence.deleteAll();
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  create,
  findAll,
  findOne,
  update,
  deleteOne,
  deleteAll,
};
